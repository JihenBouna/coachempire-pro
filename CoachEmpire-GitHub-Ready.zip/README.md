# CoachEmpire Pro V2

## Déploiement Netlify via GitHub

### 1. Crée un repo GitHub
```
git init
git add .
git commit -m "Initial deploy"
git remote add origin https://github.com/TON_USERNAME/coachempire-pro.git
git push -u origin main
```

### 2. Connecte Netlify à GitHub
- app.netlify.com → "Add new site" → "Import an existing project"
- Choisis GitHub → sélectionne ton repo
- Build settings: laisse vide (site statique avec functions)
- Clique "Deploy"

### 3. Ajoute la clé API
- Site configuration → Environment variables
- ANTHROPIC_API_KEY = sk-ant-...

C'est tout ! Les functions se déploient automatiquement.
